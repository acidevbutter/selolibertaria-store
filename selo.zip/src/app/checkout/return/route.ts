import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import Stripe from "stripe";
import { env, publicUrl } from "@/env.mjs";
import { requireAuth } from "@/lib/api-auth";
import { getDb } from "@/lib/mongodb";

const stripe = env.STRIPE_SECRET_KEY ? new Stripe(env.STRIPE_SECRET_KEY, { apiVersion: undefined }) : null;

type CheckoutStatus =
	| "success"
	| "processing"
	| "requires_payment_method"
	| "open"
	| "expired"
	| "failed"
	| "cancel"
	| "unknown";

const REDIRECT_PARAM = "checkout";

export async function GET(req: NextRequest) {
	const orderId = req.nextUrl.searchParams.get("order");
	const paymentIntentId =
		req.nextUrl.searchParams.get("payment_intent") || req.nextUrl.searchParams.get("intent");
	const sessionId = req.nextUrl.searchParams.get("session_id");
	const cancel = req.nextUrl.searchParams.get("cancel");
	const redirectBase = publicUrl.replace(/\/$/, "");

	if (cancel) {
		return NextResponse.redirect(
			buildRedirectUrl(redirectBase, {
				[REDIRECT_PARAM]: "cancel",
			}),
		);
	}

	if (orderId || paymentIntentId) {
		if (orderId && !orderId.startsWith("ord_")) {
			return NextResponse.redirect(
				buildRedirectUrl(redirectBase, {
					[REDIRECT_PARAM]: "error",
				}),
			);
		}

		if (paymentIntentId && !paymentIntentId.startsWith("pi_")) {
			return NextResponse.redirect(
				buildRedirectUrl(redirectBase, {
					[REDIRECT_PARAM]: "invalid_payment_intent",
				}),
			);
		}

		if (!stripe) {
			return NextResponse.redirect(
				buildRedirectUrl(redirectBase, {
					[REDIRECT_PARAM]: "stripe_not_configured",
				}),
			);
		}

		const auth = await requireAuth();
		if ("error" in auth) {
			return NextResponse.redirect(`${redirectBase}/login?next=checkout`);
		}

		try {
			const db = await getDb();
			const draft = orderId
				? await db.collection("orderDrafts").findOne<{ paymentIntentId: string; userId: string }>({
						orderId,
						userId: String(auth.session.sub),
					})
				: null;
			const resolvedPaymentIntentId = paymentIntentId || draft?.paymentIntentId;
			if (!resolvedPaymentIntentId?.startsWith("pi_")) {
				return NextResponse.redirect(
					buildRedirectUrl(redirectBase, {
						[REDIRECT_PARAM]: "error",
					}),
				);
			}

			const paymentIntent = await stripe.paymentIntents.retrieve(resolvedPaymentIntentId);
			if (paymentIntent.metadata?.userId && paymentIntent.metadata.userId !== String(auth.session.sub)) {
				return NextResponse.redirect(
					buildRedirectUrl(redirectBase, {
						[REDIRECT_PARAM]: "forbidden",
					}),
				);
			}

			const sp = new URLSearchParams();
			if (orderId) sp.set("order", orderId);
			else sp.set("payment_intent", paymentIntent.id);
			sp.set("checkout", derivePaymentIntentCheckoutStatus(paymentIntent.status));
			return NextResponse.redirect(`${redirectBase}/checkout/processing?${sp.toString()}`);
		} catch (error) {
			console.error("[checkout/return] Failed to retrieve payment intent", error);
			return NextResponse.redirect(
				buildRedirectUrl(redirectBase, {
					[REDIRECT_PARAM]: "error",
				}),
			);
		}
	}

	if (!sessionId) {
		return NextResponse.redirect(
			buildRedirectUrl(redirectBase, {
				[REDIRECT_PARAM]: "missing_session",
			}),
		);
	}

	if (!stripe) {
		return NextResponse.redirect(
			buildRedirectUrl(redirectBase, {
				[REDIRECT_PARAM]: "stripe_not_configured",
				session_id: sessionId,
			}),
		);
	}

	try {
		const session = await stripe.checkout.sessions.retrieve(sessionId, {
			expand: ["payment_intent"],
		});

		const status = deriveCheckoutStatus(session);

		if (status === "success" || status === "processing") {
			const sp = new URLSearchParams();
			sp.set("session_id", sessionId);
			sp.set("checkout", status);
			return NextResponse.redirect(`${redirectBase}/checkout/processing?${sp.toString()}`);
		}

		return NextResponse.redirect(
			buildRedirectUrl(redirectBase, {
				[REDIRECT_PARAM]: status,
				session_id: sessionId,
			}),
		);
	} catch (error) {
		console.error("[checkout/return] Failed to retrieve session", error);
		return NextResponse.redirect(
			buildRedirectUrl(redirectBase, {
				[REDIRECT_PARAM]: "error",
				session_id: sessionId,
			}),
		);
	}
}

function deriveCheckoutStatus(session: Stripe.Checkout.Session): CheckoutStatus {
	const paymentStatus = session.payment_status;
	const sessionStatus = session.status;
	const paymentIntent =
		typeof session.payment_intent === "object" ? (session.payment_intent as Stripe.PaymentIntent) : undefined;

	if (
		paymentStatus === "paid" ||
		paymentStatus === "no_payment_required" ||
		paymentIntent?.status === "succeeded"
	) {
		return "success";
	}

	if (paymentIntent?.status === "processing") {
		return "processing";
	}

	if (
		paymentIntent?.status === "requires_payment_method" ||
		paymentIntent?.status === "requires_action" ||
		paymentIntent?.status === "requires_confirmation" ||
		paymentIntent?.status === "requires_capture"
	) {
		return "requires_payment_method";
	}

	if (sessionStatus === "expired") {
		return "expired";
	}

	if (sessionStatus === "open") {
		return "open";
	}

	if (sessionStatus === "complete" && paymentStatus === "unpaid") {
		return "failed";
	}

	return "unknown";
}

function derivePaymentIntentCheckoutStatus(status: Stripe.PaymentIntent.Status): CheckoutStatus {
	if (status === "succeeded") return "success";
	if (status === "processing") return "processing";
	if (
		status === "requires_payment_method" ||
		status === "requires_action" ||
		status === "requires_confirmation" ||
		status === "requires_capture"
	) {
		return "requires_payment_method";
	}
	if (status === "canceled") return "cancel";
	return "unknown";
}

function buildRedirectUrl(base: string, params: Record<string, string | undefined>) {
	const searchParams = new URLSearchParams();
	for (const [key, value] of Object.entries(params)) {
		if (value) searchParams.set(key, value);
	}

	const qs = searchParams.toString();
	return qs ? `${base}/?${qs}` : `${base}/`;
}
