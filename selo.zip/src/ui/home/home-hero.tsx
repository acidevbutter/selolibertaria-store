import Image from "next/image";
import { getLocale } from "@/i18n/server";
import type { EditorialHomePage } from "@/lib/editorial-content";
import { EditorialEyebrow, EditorialShell } from "@/ui/editorial/editorial-primitives";
import { LiftOnHover, Reveal } from "@/ui/motion/reveal";
import { YnsLink } from "@/ui/yns-link";

export async function HomeHero({ content }: { content?: EditorialHomePage["hero"] | null }) {
	const locale = await getLocale();
	const isPortuguese = locale === "pt-BR";
	const hero = content ?? null;
	const eyebrow = hero?.eyebrow || (isPortuguese ? "Lançamento" : "Featured release");
	const title = hero?.title || "Ninfas do Tiete";
	const description =
		hero?.description ||
		(isPortuguese
			? "Um romance breve, noturno e urbano em que desejo, cidade e memória atravessam a leitura como presença."
			: "A brief nocturnal urban novel where desire, the city, and memory move through reading as presence.");
	const primaryCtaLabel = hero?.primaryCtaLabel || (isPortuguese ? "Comprar livro" : "Buy the book");
	const secondaryCtaLabel =
		hero?.secondaryCtaLabel || (isPortuguese ? "Conhecer o Sarau Safado" : "Discover Sarau Safado");
	const supportingLine =
		hero?.supportingLine ||
		(isPortuguese
			? "Livros impressos, edições sonoras, encontros ao vivo e projetos culturais."
			: "Printed books, sonic editions, live gatherings, and cultural projects.");
	const quoteEyebrow = hero?.featureEyebrow || (isPortuguese ? "Trecho" : "Reading note");
	const quote =
		hero?.featureQuote ||
		(isPortuguese
			? "Ler também pode ser uma forma de acender presença."
			: "Reading can also be a way of igniting presence.");
	const featureImage = hero?.featureImage?.src || "/images/ninfas-example.png";
	const featureImageAlt = hero?.featureImage?.alt || title;

	return (
		<section className="overflow-hidden bg-[color:var(--editorial-ink)] text-[color:var(--editorial-paper)]">
			<EditorialShell className="grid min-h-[720px] grid-cols-1 gap-12 py-8 sm:py-10 lg:min-h-[834px] lg:grid-cols-[minmax(0,0.88fr)_minmax(360px,0.92fr)] lg:items-center lg:gap-20 lg:py-16 xl:py-20">
				<div className="flex max-w-2xl flex-col justify-center space-y-6 lg:space-y-8">
					<Reveal>
						<EditorialEyebrow className="text-[color:var(--editorial-beige)] sm:text-sm">
							{eyebrow}
						</EditorialEyebrow>
					</Reveal>
					<Reveal delay={0.05}>
						<h1 className="display-font max-w-[8ch] text-balance text-[3.45rem] leading-[0.84] font-black tracking-[-0.07em] text-[color:var(--editorial-paper)] uppercase sm:text-[5.2rem] lg:text-[6.2rem] xl:text-[6.7rem]">
							{title}
						</h1>
					</Reveal>
					<Reveal delay={0.1}>
						<p className="max-w-[31rem] text-pretty text-base leading-8 text-[color:rgba(247,244,239,0.76)] sm:text-lg sm:leading-8">
							{description}
						</p>
					</Reveal>
					<Reveal delay={0.15}>
						<div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap">
							<YnsLink
								href={hero?.primaryCtaHref || "/products"}
								className="inline-flex h-12 items-center justify-center bg-[color:var(--editorial-paper)] px-6 text-[11px] font-black uppercase tracking-[0.24em] text-[color:var(--editorial-ink)] transition-colors duration-300 hover:bg-[color:var(--editorial-beige)]"
							>
								{primaryCtaLabel}
							</YnsLink>
							<YnsLink
								href={hero?.secondaryCtaHref || "/sarau-safado"}
								className="inline-flex h-12 items-center justify-center border border-[color:rgba(247,244,239,0.24)] px-6 text-[11px] font-black uppercase tracking-[0.24em] text-[color:var(--editorial-paper)] transition-colors duration-300 hover:bg-[color:rgba(247,244,239,0.08)]"
							>
								{secondaryCtaLabel}
							</YnsLink>
						</div>
					</Reveal>
					<Reveal delay={0.2}>
						<p className="max-w-[28rem] text-sm leading-7 text-[color:rgba(216,208,196,0.84)]">
							{supportingLine}
						</p>
					</Reveal>
				</div>

				<div className="relative">
					<Reveal delay={0.08}>
						<LiftOnHover>
							<div className="relative mx-auto w-full max-w-[620px] pb-20 lg:mx-0 lg:pb-28">
								<div className="relative mx-auto aspect-[0.667] w-[70vw] max-w-[360px] min-w-[220px] overflow-hidden border border-[color:rgba(247,244,239,0.08)] bg-[color:#121212] shadow-[0_32px_90px_rgba(0,0,0,0.42)] lg:ml-auto lg:mr-0 lg:w-full lg:max-w-[360px]">
									<Image
										src={featureImage}
										alt={featureImageAlt}
										fill
										priority
										className="object-cover object-center transition-transform duration-700"
										sizes="(max-width: 1024px) 72vw, 520px"
									/>
								</div>
								<div className="absolute right-0 bottom-0 w-[82%] max-w-[320px] border border-[color:var(--editorial-ink)] bg-[color:var(--editorial-paper)] p-6 text-[color:var(--editorial-ink)] shadow-[0_22px_50px_rgba(11,11,11,0.24)] lg:right-[-1.5rem]">
									<p className="text-[10px] font-black uppercase tracking-[0.24em] text-[color:var(--editorial-accent)]">
										{quoteEyebrow}
									</p>
									<p className="mt-4 text-xl leading-tight font-medium sm:text-[2rem]">{quote}</p>
								</div>
							</div>
						</LiftOnHover>
					</Reveal>
				</div>
			</EditorialShell>
		</section>
	);
}
